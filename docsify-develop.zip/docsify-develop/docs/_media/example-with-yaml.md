---
author: John Smith
date: 2020-1-1
---

> This is from the `example.md`
